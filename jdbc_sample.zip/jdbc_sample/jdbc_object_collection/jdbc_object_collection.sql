/*Address information as an Object*/
create or replace type ADDRESS_TYPE AS object
(
street varchar2(50), 
city varchar2(25),                      
state varchar2(25), 
zip number
);

/*Address information as list of addresses store in table type*/
create or replace type ADDRESS_TBL
as table of ADDRESS_TYPE;

/*nested object - name associted with Address object*/
create or replace type PERSON_TYPE as object
(                                     
name varchar2(25), 
address ADDRESS_TYPE
);         

/*table with nested object as data type*/
Create table SINGLE_ADDRESS_CUSTOMER
(                                             
customer_id number, 
person PERSON_TYPE
);        

/*table with nested object as data type*/
Create table MULTI_ADDRESS_CUSTOMER
(                                             
customer_id number,
cust_name varchar2(25),
addresses ADDRESS_TBL
)
NESTED TABLE addresses STORE AS ADDRESS_TAB
LOGGING 
NOCACHE
NOPARALLEL;

CREATE OR REPLACE procedure add_single_address_customer
(
customer_id in number,
person in person_type
)
is
begin
insert into single_address_customer values (customer_id, person);
commit;
end;
/

CREATE OR REPLACE procedure add_multi_address_customer
(
customer_id in number,
customer_name in varchar2,
addresses address_tbl
)
is
begin
insert into multi_address_customer values (customer_id, customer_name, addresses);
commit;
end;
/

