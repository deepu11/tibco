package photocatalog;

import java.util.Iterator;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;

import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.GenericHandler;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.AttachmentPart;
import java.awt.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.xml.soap.MessageFactory;

public class BWMessageHandler extends GenericHandler {

    String[] MIME_HEADERS = { "Server", "Date", "Content-length", "Content-type", "SOAPAction" };
	private String BWSOAP_SERVER_DIR = "c:/temp";
	FileOutputStream log;

	public BWMessageHandler(){
		try{
			log = new FileOutputStream(new File(BWSOAP_SERVER_DIR + "/bwlog.txt"));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public boolean handleRequest(MessageContext context) {
		try{
			SOAPMessage message = ((SOAPMessageContext)context).getMessage();
			String imageName = "tibco.jpg";
			AttachmentPart att = MessageFactory.newInstance().createMessage().createAttachmentPart();
			att.setContentId("<" + imageName + ">");
			java.awt.Image photo = getImage("tibco.jpg");
			att.setContent(photo,"image/jpeg");
			message.addAttachmentPart(att);
			log.write("sending the request \n".getBytes());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		logMessage("request", context);
		return true;
	}

	public boolean handleResponse(MessageContext context) {
		try{
		log.write("Received the response \n".getBytes());
		logMessage("response", context);
		SOAPMessage message = ((SOAPMessageContext)context).getMessage();
        Iterator iter = message.getAttachments();
        if(iter.hasNext()){
            AttachmentPart part = (AttachmentPart)iter.next();
			Object obj = part.getContent();
			if(obj instanceof Image){
				//Store the photo.
				FileOutputStream file = new FileOutputStream(BWSOAP_SERVER_DIR + "/fooImage.jpg");
				log.write(("Writing the image to  " + BWSOAP_SERVER_DIR + "/fooImage.jpg" + " \n").getBytes());
				ImageIO.write((BufferedImage)obj, "jpeg", file);
			}
        }else{
            System.out.println("No attachments received");
        }

		logMessage("response", context);
		}catch(Exception e){
			e.printStackTrace();}
		return true;
	}


	public boolean handleFault(MessageContext context) {
		logMessage("fault", context);
		return true;
	}

	private void logMessage(String method, MessageContext context) {
		try{
			log.write(logSOAPMessage(context).getBytes());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	
	String logSOAPMessage(MessageContext context) {
		StringBuffer stringBuffer = new StringBuffer();
		SOAPMessageContext smc = (SOAPMessageContext) context;
		SOAPMessage soapMessage = smc.getMessage();

		ByteArrayOutputStream bout= new ByteArrayOutputStream();
		try {
			soapMessage.writeTo(bout);
		} catch(Exception e) {
			e.printStackTrace(System.out);
		}
		stringBuffer.append(bout.toString() + "\n");

		return stringBuffer.toString();
	} 
     
	public QName[] getHeaders() { return new QName[0]; }

	private static Image getImage(String imageName) throws Exception{
			String imageLocation = getDataDir() + imageName;
			return javax.imageio.ImageIO.read(new File(imageLocation));
	}
	   
	private static String getDataDir() {
		String userDir = System.getProperty("user.dir");
		String sepChar = System.getProperty("file.separator");
		return userDir+sepChar+ "data/";    
	}

}

