

import com.sun.xml.wss.ProcessingContext;
import com.sun.xml.wss.XWSSecurityException;

import javax.xml.soap.SOAPMessage;

/**
 * Created by IntelliJ IDEA.
 * User: rduntulu
 * Date: Dec 19, 2005
 * Time: 11:09:42 AM
 * To change this template use Options | File Templates.
 */
public interface XWSSMsgProcessor {

 public  SOAPMessage secureOutboundMessage(
        ProcessingContext messageCntxt)
        throws XWSSecurityException;

 public SOAPMessage verifyInboundMessage(
        ProcessingContext messageCntxt)
        throws XWSSecurityException;
}
