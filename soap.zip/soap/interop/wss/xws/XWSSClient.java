

import com.sun.xml.wss.ProcessingContext;

import javax.xml.soap.*;
import java.io.*;
import java.net.URL;
import java.net.HttpURLConnection;

/**
 * Created by IntelliJ IDEA.
 * User: rduntulu
 * Date: Dec 19, 2005
 * Time: 11:34:15 AM
 * To change this template use Options | File Templates.
 */
public class XWSSClient {

        public static void main(String[] args) throws Exception {


            FileInputStream clientConfig = null;
            FileInputStream serverConfig = null;
            try {
                //read client side security configuration
                clientConfig = new java.io.FileInputStream(
                        new java.io.File("wss-client-config.xml"));
                //read server side security configuration
                serverConfig = new java.io.FileInputStream(
                        new java.io.File("wss-server-config.xml"));
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            }

            //Create a XWSSMsgProcessorFactoy.
            XWSSMsgProcessorFactoy factory = XWSSMsgProcessorFactoy.newInstance();

            //Create XWSSMsgProcessor to secure out going soap messages.
            //Sample SecurityEnvironment is configured to
            //use client side keystores.

            XWSSMsgProcessor cprocessor =
                    factory.createForSecurityConfiguration(
                    clientConfig, new SecurityPropertyHandler("client"));

            //Create XWSSMsgProcessor to veriy incomming soap messages.
            //Sample SecurityEnvironment is configured to
            //use server side keystores.

            XWSSMsgProcessor sprocessor =
                    factory.createForSecurityConfiguration(
                    serverConfig, new SecurityPropertyHandler("server"));
            try{
                clientConfig.close();
                serverConfig.close();
            }catch(Exception ex){
                ex.printStackTrace();
               return;
            }

            for(int i=0;i<1;i++){

                // create SOAPMessage
                SOAPMessage msg = MessageFactory.newInstance().createMessage();
                SOAPBody body = msg.getSOAPBody();
                SOAPBodyElement sbe = body.addBodyElement(
                        SOAPFactory.newInstance().createName(
                        "Author",
                        "ns0",
                        "http://www.example.com/xsd/books"));
                sbe.addTextNode("Vivek Ranadive");


                //Create processing context and set the soap
                //message to be processed.
                ProcessingContext context = new ProcessingContext();
                context.setSOAPMessage(msg);



                //secure the message.
                SOAPMessage secureMsg = cprocessor.secureOutboundMessage(context);

                ByteArrayOutputStream bout = new  ByteArrayOutputStream();
                secureMsg.writeTo(bout);

                System.out.println("Soap Message:" +bout.toString()) ;

                String url = "http://localhost:9696/QueryBooksByAuthor";

                String soapAction = "/QueryBooksByAuthor";

                byte[] resp = sendSoapMessage(url, soapAction, bout.toByteArray()) ;



                //verify the secured message.
                MimeHeaders mimeHeaders = new MimeHeaders();
                mimeHeaders.addHeader("Content-Type", "text/xml");
                MessageFactory soapMessageFactory = MessageFactory.newInstance();
                SOAPMessage response = soapMessageFactory.createMessage(mimeHeaders, new ByteArrayInputStream(resp));
                context = new ProcessingContext();
                context.setSOAPMessage(response);

                SOAPMessage verifiedMsg= null;
                try{
                    verifiedMsg= sprocessor.verifyInboundMessage(context);
                    verifiedMsg.writeTo(bout);

                    System.out.println(verifiedMsg.getSOAPBody().toString());

                }catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        }
    private static byte[] sendSoapMessage(String httpURL, String soapAction, byte[] reqMessage)
       {

           try{
               URL  url = new URL(httpURL);
               HttpURLConnection urlConnection =  (HttpURLConnection) url.openConnection();
               urlConnection.setRequestMethod("POST");
               urlConnection.setDoOutput(true);
               urlConnection.setDoInput(true);
               urlConnection.setRequestProperty("Content-Type", "text/xml");
               urlConnection.setRequestProperty("SoapAction", soapAction);

               BufferedOutputStream writer = new BufferedOutputStream(urlConnection.getOutputStream());
               writer.write(reqMessage);
               writer.flush();
               InputStream is = urlConnection.getInputStream();
               int len = 0;
               ByteArrayOutputStream bos = new ByteArrayOutputStream();
               byte[] buf = new byte[1024];
               while ((len = is.read(buf)) > 0) {
                    bos.write(buf, 0, len);
               }
               return bos.toByteArray();
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
               System.out.println(ex.getMessage());
           }
           return null;
       }


    }


