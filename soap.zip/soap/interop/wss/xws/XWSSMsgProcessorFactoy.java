
import com.sun.xml.wss.XWSSecurityException;

import javax.security.auth.callback.CallbackHandler;
import java.io.InputStream;
/**
 * Created by IntelliJ IDEA.
 * User: rduntulu
 * Date: Dec 19, 2005
 * Time: 11:12:56 AM
 * To change this template use Options | File Templates.
 */


    public  class XWSSMsgProcessorFactoy {

        public static final String
            DEFAULT_XWSS_PROCESSOR_FACTORY =
                  "XWSSMsgProcessorFactoy";


        public static XWSSMsgProcessorFactoy newInstance()
            throws XWSSecurityException {

            ClassLoader classLoader;
            try {
                classLoader = Thread.currentThread().getContextClassLoader();
            } catch (Exception x) {
                throw new XWSSecurityException(x.toString(), x);
            }
            try {

                 return (XWSSMsgProcessorFactoy)newInstance(DEFAULT_XWSS_PROCESSOR_FACTORY, classLoader);

            } catch (SecurityException se) {
                   throw new XWSSecurityException(se.toString(), se);
            }
        }

        public XWSSMsgProcessor createForSecurityConfiguration(
        InputStream securityConfiguration,
        CallbackHandler handler) throws XWSSecurityException {
        return new XWSSMsgProcessorImpl(securityConfiguration, handler);
    }


    public XWSSMsgProcessor createForApplicationSecurityConfiguration(
        InputStream securityConfiguration) throws XWSSecurityException {
        return new XWSSMsgProcessorImpl(securityConfiguration);
    }
        private static Object newInstance(String className,
                                          ClassLoader classLoader)
            throws XWSSecurityException {
            try {
                Class spiClass;
                if (classLoader == null) {
                    spiClass = Class.forName(className);
                } else {
                    spiClass = classLoader.loadClass(className);
                }
                return spiClass.newInstance();
            } catch (ClassNotFoundException x) {
                throw new XWSSecurityException(
                    "Processor Factory " + className + " not found", x);
            } catch (Exception x) {
                throw new XWSSecurityException(
                    "Processor Factory " + className + " could not be instantiated: " + x,x);
            }
        }

    }


