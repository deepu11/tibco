

import java.io.*;

import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.configuration.NullProvider;
import org.apache.axis.client.AxisClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.HttpClient;
import org.apache.ws.security.message.WSAddTimestamp;
import org.apache.ws.security.message.WSSignEnvelope;
import org.apache.ws.security.message.WSEncryptBody;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngine;
import org.apache.ws.security.WSPasswordCallback;
import org.apache.ws.security.components.crypto.CryptoFactory;
import org.apache.ws.security.components.crypto.Crypto;
import org.w3c.dom.Document;
import org.apache.ws.axis.security.util.AxisUtil;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.callback.CallbackHandler;

/**
 * Created by IntelliJ IDEA.
 * User: rduntulu
 * Date: Dec 16, 2005
 * Time: 9:47:27 AM
 * To change this template use Options | File Templates.
 */
public class WSS4JClient implements  CallbackHandler{

    public static void main(String[] args)
    {
       WSS4JClient client = null;

       try{
          client = new WSS4JClient();
          byte[] signedAndEncMessage = client.createMessage();
          // post this message to the server
          String url = "http://localhost:9696/QueryBooksByAuthor";
          String soapAction = "/QueryBooksByAuthor";
          HttpResponse resp= client.postSoapMessage(url, soapAction, signedAndEncMessage);

          if(resp.getResponseCode()!= 200){
             System.out.println("Server some problem in processing the request, check the servers log..");
             System.out.println("Servers Response:");
             System.out.println(resp.getBody());
          }
          else
          {

             String responseMsg = resp.getBody();
             String decryptedBody = client.verifyMessage(signedAndEncMessage);

             System.out.println("Decrypted Soap Body :");
             System.out.println(decryptedBody);
          }
       }
       catch(Exception ex)
       {
           ex.printStackTrace();
       }

       System.exit(-1);
    }

    public byte[] createMessage() throws Exception {

        WSSecurityEngine secEngine = new WSSecurityEngine();
        AxisClient tmpEngine = new AxisClient(new NullProvider());
        MessageContext msgContext = new MessageContext(tmpEngine);

        InputStream in = new FileInputStream("soap-msg.xml");
        Message message = new Message(in);
        message.setMessageContext(msgContext);

        Crypto crypto = CryptoFactory.getInstance("cryptoSKI.properties");
        SOAPEnvelope unsignedEnvelope = message.getSOAPEnvelope();
        Document doc = unsignedEnvelope.getAsDocument();

        WSAddTimestamp wats = new WSAddTimestamp();
        wats.build(doc, 100 );

        WSSignEnvelope builder = new WSSignEnvelope();
        builder.setUserInfo("bob", "password");
        builder.setKeyIdentifierType(WSConstants.SKI_KEY_IDENTIFIER);

        Document signedDoc = builder.build(doc, crypto);

         Message signedMsg = (Message) AxisUtil.toSOAPMessage(signedDoc);

        // encrypt this message

        Document encDoc = null;


        WSEncryptBody encrypt = new WSEncryptBody();

        encrypt.setUserInfo("alice", "password");

        encrypt.setKeyIdentifierType(WSConstants.SKI_KEY_IDENTIFIER);

        encrypt.setSymmetricEncAlgorithm(WSConstants.AES_128);

        encDoc = encrypt.build(signedDoc, crypto);

        // end of encryption

        signedMsg = (Message) AxisUtil.toSOAPMessage(encDoc);

        ByteArrayOutputStream bout = new  ByteArrayOutputStream();
        signedMsg.writeTo(bout);
        byte[] rawSoapMessage = bout.toByteArray();
        return rawSoapMessage;
    }

    public String  verifyMessage(byte[] response) throws Exception
    {
        WSSecurityEngine secEngine = new WSSecurityEngine();
        AxisClient tmpEngine = new AxisClient(new NullProvider());
        MessageContext msgContext = new MessageContext(tmpEngine);
        ByteArrayInputStream bin = new ByteArrayInputStream(response);
        Message message = new Message(bin);
        message.setMessageContext(msgContext);
        Crypto crypto = CryptoFactory.getInstance("cryptoSKI.properties");
        Document signedDoc =  message.getSOAPEnvelope().getAsDocument();
        secEngine.processSecurityHeader(signedDoc, null, this, crypto);
        AxisUtil.updateSOAPMessage(signedDoc, message);
        //SOAPUtil.updateSOAPMessage(signedDoc, message);
        String decryptedBody = message.getSOAPPartAsString();
        return  decryptedBody;

    }

    public void handle(Callback[] callbacks)
            throws IOException, UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
            if (callbacks[i] instanceof WSPasswordCallback) {
                WSPasswordCallback pc = (WSPasswordCallback) callbacks[i];
                /*
                 * here call a function/method to lookup the password for
                 * the given identifier (e.g. a user name or keystore alias)
                 * e.g.: pc.setPassword(passStore.getPassword(pc.getIdentfifier))
                 * for Testing we supply a fixed name here.
                 */
                pc.setPassword("password");
            } else {
                throw new UnsupportedCallbackException(callbacks[i], "Unrecognized Callback");
            }
        }
    }

    public HttpResponse postSoapMessage( String url, String soapAction, byte[] reqMessage)
    {
        PostMethod post = new PostMethod(url);
        ByteArrayInputStream bin = new ByteArrayInputStream(reqMessage);
        post.setRequestEntity(new InputStreamRequestEntity(
                   bin, bin.available()));
        // Specify content type and encoding
        // If content encoding is not explicitly specified
        // ISO-8859-1 is assumed
        post.setRequestHeader("Content-type", "text/xml; charset=ISO-8859-1");
        post.setRequestHeader ("SoapAction", soapAction);
        // Get HTTP client
        HttpClient httpclient = new HttpClient();
        // Execute request
        String response = null;
        HttpResponse httpResp = null;
        try {
            int result = httpclient.executeMethod(post);

           response = post.getResponseBodyAsString();

           httpResp = new HttpResponse(response, result);
        }catch(Exception ex)
        {
            ex.printStackTrace();
        } finally {
                   // Release current connection to the connection pool once you are done
                   post.releaseConnection();
       }
       return httpResp;
    }

     class HttpResponse {
        String body;
        int respCode;

        public  HttpResponse(String b, int rc)
        {
            body = b;
            respCode = rc;
        }

        public String getBody()
        {
            return body;
        }

        public int getResponseCode()
        {
            return respCode;
        }
    }


}
