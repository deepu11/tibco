-- ****************************************************
--   TIBCO BusinessWorks 
--
--   Creates test tables for XA transaction example 
--   on Oracle Database
-- ****************************************************

-- Create table-1
DROP TABLE bwTxTest;
CREATE TABLE bwTxTest (
   userData VARCHAR(60)
);


/



COMMIT;
